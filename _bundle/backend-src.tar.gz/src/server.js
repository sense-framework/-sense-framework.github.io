import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { MongoClient, ObjectId } from 'mongodb';
import { z } from 'zod';

const env = {
  port: Number(process.env.PORT || 8080),
  mongoUri: process.env.MONGODB_URI || '',
  dbName: process.env.MONGODB_DB || 'sense_web_os',
  jwtSecret: process.env.JWT_SECRET || '',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  adminEmail: String(process.env.ADMIN_EMAIL || '').trim().toLowerCase(),
  origins: String(process.env.CORS_ORIGINS || 'http://localhost:5500').split(',').map(v => v.trim()).filter(Boolean),
  trustProxy: Number(process.env.TRUST_PROXY || 1)
};

if (!env.mongoUri) throw new Error('MONGODB_URI is required');
if (env.jwtSecret.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters');

const client = new MongoClient(env.mongoUri, { maxPoolSize: 20, minPoolSize: 1, serverSelectionTimeoutMS: 10000 });
await client.connect();
const db = client.db(env.dbName);
const users = db.collection('users');
const messages = db.collection('messages');
const announcements = db.collection('announcements');
const auditEvents = db.collection('audit_events');

await Promise.all([
  users.createIndex({ email: 1 }, { unique: true }),
  users.createIndex({ username: 1 }, { unique: true }),
  users.createIndex({ status: 1, displayName: 1 }),
  messages.createIndex({ senderId: 1, recipientId: 1, createdAt: -1 }),
  messages.createIndex({ recipientId: 1, readAt: 1, createdAt: -1 }),
  announcements.createIndex({ createdAt: -1 }),
  auditEvents.createIndex({ createdAt: -1 }),
  auditEvents.createIndex({ actorId: 1, createdAt: -1 })
]);

const app = express();
app.set('trust proxy', env.trustProxy);
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin(origin, callback) {
    if (!origin || env.origins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin is not allowed'));
  },
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  maxAge: 86400
}));
app.use(express.json({ limit: '64kb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 180, standardHeaders: true, legacyHeaders: false }));

const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 25, standardHeaders: true, legacyHeaders: false });
const messageLimiter = rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false });

const objectId = value => ObjectId.isValid(value) ? new ObjectId(value) : null;
const publicUser = user => ({
  id: user._id.toString(),
  displayName: user.displayName,
  username: user.username,
  role: user.role,
  status: user.status,
  createdAt: user.createdAt,
  lastSeenAt: user.lastSeenAt || null
});
const signToken = user => jwt.sign({ sub: user._id.toString(), role: user.role, ver: user.tokenVersion || 0 }, env.jwtSecret, { expiresIn: env.jwtExpiresIn, issuer: 'sense-web-os' });

async function audit(action, actor, target = null, metadata = {}) {
  await auditEvents.insertOne({
    action,
    actorId: actor?._id || null,
    actor: actor ? { username: actor.username, role: actor.role } : null,
    targetId: target?._id || null,
    target: target ? { username: target.username, role: target.role } : null,
    metadata,
    createdAt: new Date()
  });
}

async function requireAuth(req, res, next) {
  try {
    const header = req.get('authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) return res.status(401).json({ error: 'Authentication required' });
    const decoded = jwt.verify(token, env.jwtSecret, { issuer: 'sense-web-os' });
    const id = objectId(decoded.sub);
    if (!id) return res.status(401).json({ error: 'Invalid session' });
    const user = await users.findOne({ _id: id });
    if (!user || user.status !== 'active' || (user.tokenVersion || 0) !== (decoded.ver || 0)) return res.status(401).json({ error: 'Session is no longer active' });
    req.user = user;
    users.updateOne({ _id: user._id }, { $set: { lastSeenAt: new Date() } }).catch(() => {});
    return next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Administrator access required' });
  return next();
}

const registerSchema = z.object({
  displayName: z.string().trim().min(2).max(50),
  username: z.string().trim().toLowerCase().regex(/^[a-z0-9_.-]{3,24}$/),
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(10).max(128).regex(/[a-z]/).regex(/[A-Z]/).regex(/[0-9]/)
});
const loginSchema = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(128) });
const messageSchema = z.object({ body: z.string().trim().min(1).max(4000) });
const broadcastSchema = z.object({ title: z.string().trim().min(1).max(100), body: z.string().trim().min(1).max(2000), level: z.enum(['info', 'warning', 'critical']).default('info') });
const adminPatchSchema = z.object({ role: z.enum(['user', 'admin']).optional(), status: z.enum(['active', 'suspended']).optional() }).refine(v => v.role || v.status, 'No changes supplied');

app.get('/health', async (_req, res) => {
  try {
    await db.command({ ping: 1 });
    res.json({ ok: true, service: 'sense-web-os-api', time: new Date().toISOString() });
  } catch {
    res.status(503).json({ ok: false, error: 'Database unavailable' });
  }
});

app.post('/api/auth/register', authLimiter, async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Registration details are invalid' });
  const { displayName, username, email, password } = parsed.data;
  const duplicate = await users.findOne({ $or: [{ email }, { username }] }, { projection: { _id: 1 } });
  if (duplicate) return res.status(409).json({ error: 'Email or username is already registered' });
  const now = new Date();
  const user = {
    displayName, username, email,
    passwordHash: await bcrypt.hash(password, 12),
    role: env.adminEmail && email === env.adminEmail ? 'admin' : 'user',
    status: 'active', tokenVersion: 0,
    createdAt: now, updatedAt: now, lastSeenAt: now
  };
  const result = await users.insertOne(user);
  user._id = result.insertedId;
  await audit('user.registered', user, user);
  return res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Email and password are required' });
  const user = await users.findOne({ email: parsed.data.email });
  const valid = user && await bcrypt.compare(parsed.data.password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: 'Email or password is incorrect' });
  if (user.status !== 'active') return res.status(403).json({ error: 'Account is suspended' });
  await users.updateOne({ _id: user._id }, { $set: { lastSeenAt: new Date() } });
  await audit('user.login', user, user);
  return res.json({ token: signToken(user), user: publicUser(user) });
});

app.get('/api/me', requireAuth, (req, res) => res.json({ user: publicUser(req.user) }));
app.post('/api/auth/logout', requireAuth, async (req, res) => { await audit('user.logout', req.user, req.user); res.status(204).end(); });

app.get('/api/users', requireAuth, async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 60);
  const filter = { _id: { $ne: req.user._id }, status: 'active' };
  if (q) filter.$or = [
    { displayName: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' } },
    { username: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $options: 'i' } }
  ];
  const result = await users.find(filter, { projection: { passwordHash: 0, email: 0, tokenVersion: 0 } }).sort({ displayName: 1 }).limit(50).toArray();
  res.json({ users: result.map(publicUser) });
});

app.get('/api/announcements', requireAuth, async (_req, res) => {
  const result = await announcements.find({ active: true }).sort({ createdAt: -1 }).limit(20).toArray();
  res.json({ announcements: result.map(item => ({ id: item._id.toString(), title: item.title, body: item.body, level: item.level, createdAt: item.createdAt })) });
});

app.get('/api/conversations', requireAuth, async (req, res) => {
  const mine = req.user._id;
  const rows = await messages.find({ $or: [{ senderId: mine }, { recipientId: mine }] }).sort({ createdAt: -1 }).limit(2000).toArray();
  const byPeer = new Map();
  for (const row of rows) {
    const peerId = row.senderId.equals(mine) ? row.recipientId : row.senderId;
    const key = peerId.toString();
    const current = byPeer.get(key) || { peerId, lastMessage: row, unreadCount: 0 };
    if (row.recipientId.equals(mine) && !row.readAt) current.unreadCount += 1;
    byPeer.set(key, current);
  }
  const peers = await users.find({ _id: { $in: [...byPeer.values()].map(v => v.peerId) } }).toArray();
  const peerMap = new Map(peers.map(user => [user._id.toString(), user]));
  const conversations = [...byPeer.values()].map(item => ({
    user: publicUser(peerMap.get(item.peerId.toString())),
    unreadCount: item.unreadCount,
    lastMessage: { id: item.lastMessage._id.toString(), body: item.lastMessage.body, createdAt: item.lastMessage.createdAt }
  })).filter(item => item.user).sort((a, b) => new Date(b.lastMessage.createdAt) - new Date(a.lastMessage.createdAt));
  res.json({ conversations });
});

app.get('/api/conversations/:userId/messages', requireAuth, async (req, res) => {
  const peerId = objectId(req.params.userId);
  if (!peerId) return res.status(400).json({ error: 'Invalid user' });
  const peer = await users.findOne({ _id: peerId, status: 'active' });
  if (!peer) return res.status(404).json({ error: 'User not found' });
  const filter = { $or: [{ senderId: req.user._id, recipientId: peerId }, { senderId: peerId, recipientId: req.user._id }] };
  const result = await messages.find(filter).sort({ createdAt: 1 }).limit(500).toArray();
  await messages.updateMany({ senderId: peerId, recipientId: req.user._id, readAt: null }, { $set: { readAt: new Date() } });
  res.json({ messages: result.map(item => ({ id: item._id.toString(), senderId: item.senderId.toString(), recipientId: item.recipientId.toString(), body: item.body, createdAt: item.createdAt, readAt: item.readAt })) });
});

app.post('/api/conversations/:userId/messages', requireAuth, messageLimiter, async (req, res) => {
  const peerId = objectId(req.params.userId);
  const parsed = messageSchema.safeParse(req.body);
  if (!peerId || !parsed.success) return res.status(400).json({ error: 'Message is invalid' });
  if (peerId.equals(req.user._id)) return res.status(400).json({ error: 'Cannot message this account' });
  const peer = await users.findOne({ _id: peerId, status: 'active' });
  if (!peer) return res.status(404).json({ error: 'User not found' });
  const message = { senderId: req.user._id, recipientId: peerId, body: parsed.data.body, createdAt: new Date(), readAt: null };
  const result = await messages.insertOne(message);
  res.status(201).json({ message: { id: result.insertedId.toString(), ...message, senderId: message.senderId.toString(), recipientId: message.recipientId.toString() } });
});

app.get('/api/admin/users', requireAuth, requireAdmin, async (_req, res) => {
  const result = await users.find({}, { projection: { passwordHash: 0, tokenVersion: 0 } }).sort({ createdAt: -1 }).limit(500).toArray();
  res.json({ users: result.map(user => ({ ...publicUser(user), email: user.email })) });
});

app.patch('/api/admin/users/:userId', requireAuth, requireAdmin, async (req, res) => {
  const id = objectId(req.params.userId);
  const parsed = adminPatchSchema.safeParse(req.body);
  if (!id || !parsed.success) return res.status(400).json({ error: 'Account update is invalid' });
  const target = await users.findOne({ _id: id });
  if (!target) return res.status(404).json({ error: 'User not found' });
  if (target._id.equals(req.user._id) && parsed.data.status === 'suspended') return res.status(400).json({ error: 'You cannot suspend your own account' });
  if (target._id.equals(req.user._id) && parsed.data.role === 'user') return res.status(400).json({ error: 'You cannot remove your own administrator role' });
  const update = { ...parsed.data, updatedAt: new Date() };
  if (parsed.data.status === 'suspended' || parsed.data.role) update.tokenVersion = (target.tokenVersion || 0) + 1;
  await users.updateOne({ _id: id }, { $set: update });
  const updated = await users.findOne({ _id: id });
  await audit('admin.user_updated', req.user, updated, parsed.data);
  res.json({ user: publicUser(updated) });
});

app.post('/api/admin/broadcasts', requireAuth, requireAdmin, async (req, res) => {
  const parsed = broadcastSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Broadcast is invalid' });
  const announcement = { ...parsed.data, active: true, createdBy: req.user._id, createdAt: new Date(), updatedAt: new Date() };
  const result = await announcements.insertOne(announcement);
  await audit('admin.broadcast_created', req.user, null, { announcementId: result.insertedId.toString(), level: announcement.level });
  res.status(201).json({ announcement: { id: result.insertedId.toString(), ...parsed.data, createdAt: announcement.createdAt } });
});

app.get('/api/admin/audit', requireAuth, requireAdmin, async (req, res) => {
  const limit = Math.min(Number(req.query.limit || 100), 250);
  const result = await auditEvents.find({}).sort({ createdAt: -1 }).limit(limit).toArray();
  res.json({ events: result.map(item => ({ id: item._id.toString(), action: item.action, actor: item.actor, target: item.target, metadata: item.metadata, createdAt: item.createdAt })) });
});

app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));
app.use((error, _req, res, _next) => {
  console.error(error);
  if (error?.code === 11000) return res.status(409).json({ error: 'Record already exists' });
  return res.status(500).json({ error: 'Internal service error' });
});

const server = app.listen(env.port, () => console.log(`SENSE API listening on ${env.port}`));

async function shutdown(signal) {
  console.log(`${signal} received`);
  server.close(async () => {
    await client.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
